<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'mini_job_portal'; // Make sure this database exists

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
