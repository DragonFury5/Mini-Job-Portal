<?php
session_start();
include 'config.php';

$error = '';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Simple example: Match with dummy credentials (replace with database check later)
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['user'] = $username;
        header("Location: index.php");
        exit;
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Mini Job Portal</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .login-container {
            max-width: 400px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #0d6efd;
            margin-bottom: 20px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #0d6efd;
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0b5ed7;
        }

        .error {
            color: #e74c3c;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .forgot-password {
            margin-top: 20px;
            font-size: 14px;
        }

        .forgot-password a {
            color: #0d6efd;
            text-decoration: none;
        }

        .forgot-password a:hover {
            text-decoration: underline;
        }

       /* Footer Style */
footer {
    background-color: #0d6efd;
    color: white;
    text-align: center;
    padding: 20px;
    position: sticky;
    bottom: 20px; /* Adjust this value to move the footer up or down */
    width: 100%;
    font-size: 14px;
}

footer a {
    color: white;
    text-decoration: none;
    margin-left: 10px;
}

footer a:hover {
    text-decoration: underline;
}

    </style>
</head>
<body>

    <div class="login-container">
        <h2>Login to Your Account</h2>

        <?php if ($error): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="submit" name="login" value="Login">
        </form>

        <div class="forgot-password">
            <a href="#">Forgot your password?</a>
        </div>
    </div> 3333
    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 Nobel Gaming Company. All rights reserved.</p>
        <p><a href="#">Terms & Conditions</a> | <a href="#">Privacy Policy</a></p>
    </footer>

</body>
</html>
