<?php 
session_start();
include 'config.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mini Job Portal</title>
  <link rel="stylesheet" href="style.css">
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <header class="bg-primary text-white text-center py-4 mb-4">
    <h1>Mini Job Portal</h1>
    <nav>
    <nav>
    <button id="darkModeToggle" class="btn btn-dark ml-2">🌙 Dark Mode</button>
    <a href="jobs.php">See More Jobs</a>
    <a href="add.php">Add Job</a>
    <a href="support.php">Customer Support</a>
    <a href="settings.php">Settings</a>
    <a href="login.php">Login</a>
    <label class="switch">
        <input type="checkbox" id="darkToggle">
        <span class="slider round"></span>
    </label>
</nav>

    </nav>
  </header>

  <main class="container">

    <!-- Top 3 Latest Jobs -->
    <h2>Top 3 Latest Job Postings</h2>
<div class="job-list mb-5">
  <?php
  $sql = "SELECT * FROM jobs ORDER BY posted_date DESC LIMIT 3";
  $result = $conn->query($sql);

  while ($row = $result->fetch_assoc()):
  ?>
    <div class="job row align-items-center mb-4">
      <div class="col-md-10">
        <h3><?= htmlspecialchars($row['title']) ?></h3>
        <p><strong>Company:</strong> <?= htmlspecialchars($row['company']) ?></p>
        <p><strong>Location:</strong> <?= htmlspecialchars($row['location']) ?></p>
        <p><?= nl2br(htmlspecialchars($row['description'])) ?></p>
        <p class="text-muted"><em>Posted on <?= $row['posted_date'] ?></em></p>
      </div>
      <div class="col-md-2 text-right">
        <a href="apply.php?job_id=<?= $row['id'] ?>" class="btn btn-primary btn-lg">Apply</a>
      </div>
    </div>
  <?php endwhile; ?>
</div>


    <div class="text-center mb-5">
      <a href="jobs.php" class="btn btn-lg btn-primary">See More Jobs</a>
    </div>

    <!-- Recommended Jobs Section -->
    <h2>Recommended for You</h2>
    <div class="card-deck mb-5">
      <?php
      $rec = $conn->query("SELECT * FROM jobs ORDER BY RAND() LIMIT 3");
      while ($job = $rec->fetch_assoc()):
      ?>
        <div class="card">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title"><?= htmlspecialchars($job['title']) ?></h5>
            <p class="card-text mb-1"><strong>Company:</strong> <?= htmlspecialchars($job['company']) ?></p>
            <p class="card-text mb-1"><strong>Location:</strong> <?= htmlspecialchars($job['location']) ?></p>
            <p class="card-text flex-grow-1"><?= nl2br(htmlspecialchars(substr($job['description'],0,100))) ?>…</p>
          </div>
        </div>
      <?php endwhile; ?>
    </div>



  
  </main>
  </div>

  <!-- Bootstrap JS + dependencies -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    const toggleBtn = document.getElementById('darkModeToggle');
    toggleBtn.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
    });
</script>

</body>
</html>
